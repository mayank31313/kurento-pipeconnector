class Segmentation:
    def name(self):
        return "segmentation"